<template>
  <h3 style="text-align: center; font-size: 40px;">Quản Lý Đồng Hồ</h3>
  <form class="form container ">
    <div class="mb-3">
      <label class="form-label" for="">Tên</label>
      <input type="text" v-model="dongHo.ten" class="form-control ">
    </div>

    <br>

    <div class="mb-3">
      <label for="">Loại</label>
      <select class="form-select" aria-label="Default select example" v-model="dongHo.loai">
        <option value="Đồng Hồ Trẻ Em">Đồng Hồ Trẻ Em</option>
        <option value="Đồng Hồ Thời Trang">Đồng Hồ Thời Trang</option>
      </select>
    </div>

    <br>

    <div class="mb-3">
      <label class="form-label" for="">Giá</label>
      <input type="number" v-model="dongHo.gia" class="form-control">
    </div>

  </form>
</template>


<script setup>
defineModel('dongHo', {
  default: () => (
    {
      ten: '',
      loai: '',
      gia: ''
    }
  )
})
</script>

