<template>
  <footer style="text-align: center;">
    <h1>Footer: FPT Polytechnic - PTPM</h1>
  </footer>
</template>
