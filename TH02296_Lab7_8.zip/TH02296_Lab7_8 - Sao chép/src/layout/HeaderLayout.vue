<template>
  <header>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
      <div class="container-fluid">
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item">
              <RouterLink to="/dong-ho" class="nav-link active" aria-current="page">Trang chủ</RouterLink>
            </li>
            <li class="nav-item">
              <RouterLink to="/page" class="nav-link" href="#">Page</RouterLink>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  </header>
</template>
