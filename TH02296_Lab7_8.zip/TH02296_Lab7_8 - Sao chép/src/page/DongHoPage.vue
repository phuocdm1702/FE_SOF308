<template>
  <FormComponentDongHo v-model:dongHo="newDongHo" />
  <div class="container">
    <button class="btn btn-primary" @click="addDongHo">Add</button>
  </div>
  <table class="table container">
    <thead>
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Tên</th>
        <th scope="col">Loại</th>
        <th scope="col">Giá</th>
        <th scope="col">Chức năng</th>
      </tr>
    </thead>
    <tbody>
      <template v-for="dh in listDongHo" :key="dh.id">
        <tr>
          <td>{{ dh.id }}</td>
          <td>{{ dh.ten }}</td>
          <td>{{ dh.loai }}</td>
          <td>{{ dh.gia }}</td>
          <td >
            <button style="margin-right: 20px;" class="btn btn-secondary" @click="detail(dh)">Detail</button>
            <button class="btn btn-danger" @click="remove(dh.id)">Xóa</button>
          </td>
        </tr>
      </template>
    </tbody>
  </table>
</template>
<script setup>
import FormComponentDongHo from '@/component/FormComponentDongHo.vue';
import { ref } from 'vue';

const listDongHo = ref(
  [
    {
      "id": "1",
      "ten": "Đồng Hồ Thời Trang",
      "loai": "Đồng Hồ Thời Trang",
      "gia": 10
    },
    {
      "id": "2",
      "ten": "Đồng Hồ Trẻ Em",
      "loai": "Đồng Hồ Trẻ Em",
      "gia": 82
    },
    {
      "id": "3",
      "ten": "Đồng Hồ Trẻ Em",
      "loai": "Đồng Hồ Trẻ Em",
      "gia": 44
    },
    {
      "id": "4",
      "ten": "Đồng Hồ Thời Trang",
      "loai": "loai 4",
      "gia": 58
    },
    {
      "id": "5",
      "ten": "ten 5",
      "loai": "loai 5",
      "gia": 90
    },
    {
      "id": "6",
      "ten": "ten 6",
      "loai": "loai 6",
      "gia": 63
    },
    {
      "id": "7",
      "ten": "ten 7",
      "loai": "loai 7",
      "gia": 61
    },
    {
      "id": "8",
      "ten": "ten 8",
      "loai": "loai 8",
      "gia": 4
    },
    {
      "id": "9",
      "ten": "ten 9",
      "loai": "loai 9",
      "gia": 100
    },
    {
      "id": "10",
      "ten": "ten 10",
      "loai": "loai 10",
      "gia": 63
    },
    {
      "id": "11",
      "ten": "ten 11",
      "loai": "loai 11",
      "gia": 23
    },
    {
      "id": "12",
      "ten": "ten 12",
      "loai": "loai 12",
      "gia": 66
    },
    {
      "id": "13",
      "ten": "ten 13",
      "loai": "loai 13",
      "gia": 4
    },
    {
      "id": "14",
      "ten": "ten 14",
      "loai": "loai 14",
      "gia": 42
    },
    {
      "id": "15",
      "ten": "ten 15",
      "loai": "loai 15",
      "gia": 69
    }
  ]
)

const newDongHo = ref(
  {
    ten: '',
    loai: '',
    gia: ''
  }
)
const i = ref(-1)
const detail = (item) => {
  newDongHo.value = { ...item }
  i.value = listDongHo.value.findIndex((dh) => dh.id === item.id)
}

const remove = (id) => {
  if (confirm("Bạn có muốn xóa không?")) {
    const index = listDongHo.value.findIndex((dh) => dh.id === id)
    listDongHo.value.splice(index, id)
    alert("Xóa Thành công ID:" + id)
    return;
  } else {
    alert("Bạn đã hủy xóa.")
    return;
  }
}

const addDongHo = () => {
  if (confirm("Bạn có muốn Thêm không?")) {
    listDongHo.value.push(
      {
        id: listDongHo.value.length + 1,
        ...newDongHo.value
      }
    )
    alert("Thêm Thành công.")
    return;
  } else {
    alert("Bạn đã hủy Thêm.")
    return;
  }
}

</script>
