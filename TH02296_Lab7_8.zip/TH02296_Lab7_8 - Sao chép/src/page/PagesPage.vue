<template>
  <p class="container">Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet, facilis repellat. Fugiat veniam quod saepe autem exercitationem eum. Quae unde magni earum nulla alias exercitationem laudantium atque maiores ea nam!</p>
</template>
