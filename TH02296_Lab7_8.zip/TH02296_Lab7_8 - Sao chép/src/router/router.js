import DongHoPage from "@/page/DongHoPage.vue"
import PagesPage from "@/page/PagesPage.vue"
import { createRouter, createWebHistory } from "vue-router"



const routers = [
  {
    path: '/dong-ho',
    name: 'TrangChu',
    component: DongHoPage
  },
  {
    path: '/page',
    name: 'Page',
    component: PagesPage
  },
]

const a = createRouter(
  {
    history: createWebHistory(),
    routes: routers,
  }
)

export default a
